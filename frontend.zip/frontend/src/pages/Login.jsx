import React, { useState, useEffect } from "react";
import axios from "axios";
import styled from "styled-components";
import { useNavigate, Link } from "react-router-dom";
import Logo from "../assets/Chaty1.png";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { loginRoute } from "../utils/APIRoutes";

function Login() {
    const navigate = useNavigate();
    const [values, setValues] = useState({
        email:"",
        password:""
    });


    useEffect(() => {
        async function goToChat() {
            if (localStorage.getItem(process.env.REACT_APP_LOCALHOST_KEY)) {
                navigate("/");
            }
        }
        goToChat();
    });

    const handleSubmit = async (event)=> {
        event.preventDefault();
        if(handleValidation()){
            const { email, password } = values;
            const { data } = await axios.post(loginRoute, {
                email,
                password,
            });

            if (data.status === false) {
                toast.error(data.msg, {
                    position:"bottom-center",
                    autoClose:5000,
                    pauseOnHover: true,
                });
            }
            if (data.status === true) {
                localStorage.setItem(
                process.env.REACT_APP_LOCALHOST_KEY,
                JSON.stringify(data.users)
                );
                navigate("/");
            }
        }
    };

    const handleValidation = () => {
        const {email, password} = values;
        if (password.length < 8 ){
            toast.error("Password Too Short",{
                position:"bottom-center",
                autoClose:5000,
                pauseOnHover: true,
            });
            return false;
        }else if( password === ""){
          toast.error("You Forgot The Password",{
              position:"bottom-center",
              autoClose:5000,
              pauseOnHover: true,
          });
          return false;
        }else if( email === ""){
          toast.error("You Forgot The Email",{
              position:"bottom-center",
              autoClose:5000,
              pauseOnHover: true,
          });
          return false;
        }
        return true;
    };

    const handleChange = (event) =>{
        setValues({ ...values, [event.target.name]: event.target.value });
    };

    return (
        <>
            
                <FormContainer>
                    <div className='brand'>
                            <img src={Logo} alt="logo"/>
                    </div>
                    <form onSubmit={(event) => handleSubmit(event)}>
                        <div className='other'>
                            <h1 id="ti"> Login </h1>
                            <label htmlFor="email" className="lab">Email:</label>
                            <input 
                                type="email" 
                                placeholder="Enter Email" 
                                name="email" id="email" 
                                required 
                                onChange={e=>handleChange(e)}
                            />
                            <label htmlFor="password" className="lab"><b>Password:</b></label>
                            <input 
                                type="password" 
                                placeholder="Enter Password" 
                                name="password" 
                                id="password" 
                                required
                                onChange={e=>handleChange(e)}
                            />
                            <div>
                                <button type="submit" className="registerbtn">Login</button>
                                <span>
                                    Dont have an account? <Link to="/register" className="log">Register</Link>
                                </span>
                            </div>
                        </div>
                        
                    </form>
                </FormContainer>
            <ToastContainer/>
        </>
    )
}

const FormContainer = styled.div`
    margin-left:50px;
    height: auto;
    width: 100vw;
    display: flex;
    gap: 1rem;
    background-color: white;
    .brand {
        margin-top:100px;
        display: flex;
        align-items: left;
        gap: 1rem;
        justify-content: left;
        float: left;
        img {
            height: 300px;
        }
    }
    .lab{
        margin: 10px;
        width:100%;
        display: inline-block;
    }

    #ti{
        text-align: center;
        margin: 20px;
    }

    form {
        margin-top:20px;
        width:40%;
        background-color: #808080;
        border-radius: 2rem;
        padding: 3rem 5rem;
        hight: auto;
    }
    input {
        display: inline-block;
        background-color: white;
        padding: 1rem;
        border-radius: 1.4rem;
        color: black;
        width: 90%;
        font-size: 1rem;
    }
    button {
        margin: 20px;
        display: inline-block;
        background-color: #4e0eff;
        color: white;
        padding: 1rem 2rem;
        border: none;
        font-weight: bold;
        cursor: pointer;
        border-radius: 0.4rem;
        font-size: 1rem;
        text-transform: uppercase;
    }

    button:hover {
        opacity:1;
    }

    span {
        display: inline-block;
        width: 100%;
        color: white;
        a {
            color: #4e0eff;
            text-decoration: none;
            font-weight: bold;
        }
    }

`;

export default Login;